import requests
import http.client
import json
import pymongo

def downloader(url):
    req = requests.get(url=url, allow_redirects=True)
    req = req.json()

    print(len(req))

    if len(req) >=1000:
        client = pymongo.MongoClient()
        db = client.BikeStation

        bikes = db.Bikes

        bikes.insert_many(req)

    else:
        raise ValueError


downloader("https://data.cityofchicago.org/resource/eq45-8inv.json")
