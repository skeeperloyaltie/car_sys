import pandas as pd
from prettyprinter import pprint
from pymongo import MongoClient
#from datetime import datetime
import dateutil.parser as dt
import sqlite3
#import pyperclip
#import ast
client = MongoClient()
db = client.BikeStation

bikedat = db.Bikes.find()
datadict = list(bikedat)
conn = sqlite3.connect("indexed.sqlite3")
c = conn.cursor()
c.execute("drop table if exists bikedata")
table = """ CREATE TABLE bikedata (
                _id integer PRIMARY KEY,
                id integer,
                timestamp text,
                station_name text NOT NULL,
                total_docks integer,
                dock_in_service int,
                available_docks int,
                available_bikes int,
                percent_full int,
                status text,
                lattitude double,
                longitude double,
                location text,
                record int
                                                                                      ); """

c.execute(table)

for i in range(len(datadict)):
    datadict[i].pop("_id")
    #pprint(datadict[i])
    data = [
        
             int(datadict[i]['id']),

             dt.parse(datadict[i]['timestamp']),
             str(datadict[i]['station_name']),
             int(datadict[i]['total_docks']),
             int(datadict[i]['docks_in_service']),
             int(datadict[i]['available_docks']),
             int(datadict[i]['available_bikes']),
             int(datadict[i]['percent_full']),
             str(datadict[i]['status']),
             float(datadict[i]['latitude']),
             float(datadict[i]['longitude']),
             str(datadict[i]['location']),
             str(datadict[i]['record'])
            
             ]
    
    c.execute("INSERT INTO bikedata VALUES (null,?,?,?,?,?,?,?,?,?,?,?,?,?)",data)


conn.commit()
connection = sqlite3.connect("indexed.sqlite3")
cursor = connection.cursor()
cursor.execute("SELECT * FROM bikedata;")
results = cursor.fetchall()	

cursor.close()
connection.close()
df = pd.DataFrame(results, columns=['_id', 'id', 'timestamp', 'station_name', 'total_docks', 'docks_in_service', 'available_docks', 'available_bikes', 'percent_full', 'status', 'latitude', 'longitude', 'location', 'record'])

print (df)
